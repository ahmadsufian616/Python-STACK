from django.apps import AppConfig


class SrtsAppConfig(AppConfig):
    name = 'srts_app'
